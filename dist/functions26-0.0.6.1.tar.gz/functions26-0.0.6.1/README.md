This package has been created for use in the Fu lab at UW. It contains simple functions that make our every day coding
easier.

_________________________________

To install:
    (Open cmd/terminal. Administrator privileges might be required)
    pip install functions26
