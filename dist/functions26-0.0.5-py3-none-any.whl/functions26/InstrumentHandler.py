# 2019-05-12 / last updated on 2020-09-15
# This code was made for use in the Fu lab
# by Vasilis Niaouris

import pyvisa
import nidaqmx
import serial as srl
from windfreak import SynthHD  # this is a class
import time
import warnings


class Instrument:

    def __init__(self, device_name, verbose=1, initialize_at_definition=True):
        self.device_name = device_name
        self.verbose = verbose
        self.initialize_at_definition = initialize_at_definition

        if self.initialize_at_definition and not self.device_name == '':
            self.instrument = self.initialize_instrument()
        else:
            self.instrument = None

    def initialize_instrument(self):
        warnings.warn('Assign your own initialize_instrument()')
        pass

    def terminate_instrument(self):
        warnings.warn('Assign your own terminate_instrument()')
        pass

    def reopening_session(self):
        if self.verbose > 1:
            print(self.device_name + ': Reopening session')
        self.instrument = self.initialize_instrument()

    def get_instrument_reading_string(self):
        warnings.warn('Assign your own get_instrument_reading_string()')
        pass


class GPIBInstrument(Instrument):
    read_command_number = 0

    def __init__(self, device_name='', read_termination='', read_command='', time_delay=1e-17, clear_command='*CLS',
                 verbose=1, initialize_at_definition=True):

        self.read_termination = read_termination
        self.time_delay = time_delay
        self.clear_command = clear_command
        self.read_command = read_command
        if isinstance(self.read_command, str):
            self.read_command_number = 1
        else:
            self.read_command_number = len(read_command)

        self.rm = pyvisa.ResourceManager()  # Resource manager
        super().__init__(device_name, verbose, initialize_at_definition)

    def initialize_instrument(self):

        try:
            self.instrument = self.rm.open_resource(self.device_name)
            self.instrument.write(self.clear_command)
            self.instrument.read_termination = self.read_termination
            if self.verbose > 1:
                print(self.device_name + ': Instrument successfully initialized')
            return self.instrument
        except pyvisa.errors.VisaIOError:
            print(self.device_name + ': Vis IO Error occurred. Check instrument name or if instrument is available')
            return -1

    def terminate_instrument(self):

        try:
            self.instrument.last_status
        except pyvisa.errors.InvalidSession:
            print(self.device_name + ': Invalid Session. Instrument might already be closed')
            return -1
        except AttributeError:
            print(self.device_name + ': Invalid Session. Instrument might be used by other Program')
            return -1

        try:
            # self.instrument.clear()
            self.instrument.write(self.clear_command)
            self.instrument.close()
            self.instrument = None
            if self.verbose > 1:
                print(self.device_name + ': Instrument successfully terminated')
            return 0
        except not pyvisa.errors.InvalidSession:
            print(self.device_name + ': Instrument not terminated')
            return 1

    def get_instrument_reading_string_all(self):
        results_list = []
        for i in range(self.read_command_number):
            self.instrument.write(self.read_command[i])
            time.sleep(self.time_delay)
            results_list.append(self.instrument.read())
        return results_list

    def get_instrument_reading_string(self, read_command=None):
        if read_command is None:
            if self.read_command_number <= 1:
                read_command = self.read_command
            else:
                read_command = self.read_command[0]
                print(
                    self.device_name + ': This device has more than one reading commands. I chose to read the first one.')
        self.instrument.write(read_command)
        time.sleep(self.time_delay)
        return self.instrument.read()


class NIdaqInstrument(Instrument):

    def __init__(self, device_name='', verbose=1, initialize_at_definition=True):
        self.task = None
        super().__init__(device_name, verbose, initialize_at_definition)

    def initialize_instrument(self):

        try:
            self.task = nidaqmx.Task()  # NI DAQmx task
            self.channel = self.task.ai_channels.add_ai_voltage_chan(self.device_name)
            if self.verbose > 1:
                print(self.device_name + ': Instrument successfully initialized')
            return self.channel
        except nidaqmx.errors.Error:
            print(self.device_name + ': NI DAQmx Method Error. Check instrument name or if instrument is available')
            return -1

    def terminate_instrument(self):

        try:
            if self.task.is_task_done():
                try:
                    self.task.close()
                    self.channel = None
                    if self.verbose > 1:
                        print(self.device_name + ': Instrument successfully terminated')
                except nidaqmx.errors.Error:
                    print(self.device_name + ': NI DAQmx Method Error. Could not clear task.')
            else:
                print(self.device_name + ': Task is still running')
        except nidaqmx.errors.DaqError:
            if self.verbose > 1:
                print(self.device_name + ': Task already terminated')

    def get_instrument_reading_string(self):
        return self.task.read()


class SerialInstrument(Instrument):
    read_command_number = 0

    def __init__(self, device_name='', read_command='', time_out=1, baud_rate=9600,
                 verbose=1, initialize_at_definition=True):

        self.time_out = time_out
        self.baud_rate = baud_rate
        self.read_command = read_command
        if not isinstance(self.read_command, list):
            self.read_command_number = 1
        else:
            self.read_command_number = len(read_command)

        super().__init__(device_name, verbose, initialize_at_definition)

    def initialize_instrument(self):

        try:
            self.instrument = srl.Serial(self.device_name, self.baud_rate, timeout=self.time_out)
            self.instrument.reset_input_buffer()
            self.instrument.reset_output_buffer()
            if self.verbose > 1:
                print(self.device_name + ': Instrument successfully initialized')
            return self.instrument
        except ValueError:
            print(self.device_name + ': Serial Port Error. A parameter is out of range or access was denied.')
            return -1
        except srl.SerialException:
            print(self.device_name + ': Serial Port Error. Instrument can not be found or can not be configured.')
            return -2

    def terminate_instrument(self):

        if self.instrument.is_open:
            try:
                self.instrument.reset_input_buffer()
                self.instrument.reset_output_buffer()
                self.instrument.close()
                self.instrument = None
                if self.verbose > 1:
                    print(self.device_name + ': Instrument successfully terminated')
                return 0
            except Exception as e:
                print(self.device_name + ': An error occured. Instrument was not terminated. Error: ' + str(e))
                return -1
        else:
            print(self.device_name + ': Instrument might already be closed')
            return -1

    def get_instrument_reading_string_all(self):
        results_list = []
        for i in range(self.read_command_number):
            self.instrument.write(self.read_command[i])
            results_list.append(self.instrument.readlines()[-1])
        return results_list

    def get_instrument_reading_string(self, read_command=None):
        if read_command is None:
            if self.read_command_number <= 1:
                read_command = self.read_command
            else:
                read_command = self.read_command[0]
                print(
                    self.device_name + ': This device was given more than one reading commands. Will only read the first one.')
        self.instrument.write(read_command)
        lines = self.instrument.readlines()
        return lines[-1]


class WindfreakSythHDInstrument(Instrument):  # it is a serial instrument that has it's own class based on Serial

    def __init__(self, device_name='', verbose=1, initialize_at_definition=True):
        super().__init__(device_name, verbose, initialize_at_definition)

    def initialize_instrument(self):

        try:
            self.instrument = SynthHD(self.device_name)
            self.instrument.init()
            if self.verbose > 1:
                print(self.device_name + ': Instrument successfully initialized')
            return self.instrument
        except Exception as e:
            print(self.device_name + ': SynthHD Error. Check instrument name or if instrument is available')
            return -1

    def terminate_instrument(self):

        try:
            self.instrument.close()
        except Exception as e:
            print(self.device_name + ': An error occured. Instrument was not terminated. Error: ' + str(e))

    def get_instrument_reading_string(self):
        raise RuntimeError('This read statement is too broad. Check windfreak SynthHD class for more info.')
